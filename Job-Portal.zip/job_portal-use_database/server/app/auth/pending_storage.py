# This file is no longer needed as we now use database storage (PendingUser model)
# Instead of in-memory storage for pending user registrations
